import os

def clear_screen():
    os.system('cls')

def pause_screen():
    print('Pulse Enter para continuar...')
    input()