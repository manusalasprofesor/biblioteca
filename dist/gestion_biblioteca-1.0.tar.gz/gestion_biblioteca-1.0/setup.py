from setuptools import setup
setup(
    name = 'gestion_biblioteca',
    version = '1.0',
    description = 'Paquete de gestión de biblioteca',
    author = 'Manu Plaza',
    author_email = 'manel.plaza@creationbcn.com',
    url = 'https://www.creationbcn.com',
    packages = ['modulos'],
    scripts = []  
)
